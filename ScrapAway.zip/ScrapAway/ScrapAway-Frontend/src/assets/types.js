export const wasteTypes = [
  {
    name: "Organic Waste",
    imageSrc: "./Types/organic.jpg",
    altText: "Organic Waste Image",
    description: "$10/lb",
  },
  {
    name: "Plastic Bottles & Cans",
    imageSrc: "/Types/plastic.jpg",
    altText: "Plastic Bottles & Cans Image",
    description: "$5/lb",
  },
  {
    name: "Metals",
    imageSrc: "/Types/metal.png",
    altText: "Metals Image",
    description: "$15/lb",
  },
  {
    name: "Bulky Household Items",
    imageSrc: "/Types/bulky.jpg",
    altText: "Bulky Household Items Image",
    description: "$15/lb",
  },
  {
    name: "Electronics Residue",
    imageSrc: "/Types/electronic.jpg",
    altText: "Electronics Residue Image",
    description: "$2/lb",
  },
  {
    name: "Contruction waste",
    imageSrc: "/Types/construction.jpg",
    altText: "Construction Waste Image",
    description: "$5/lb",
  },
  {
    name: "Paper Residue",
    imageSrc: "/Types/paper.jpg",
    altText: "Paper Residue Image",
    description: "$2/lb",
  },
  {
    name: "Hazardous Waste",
    imageSrc: "/Types/hazardous.jpg",
    altText: "Hazardous Waste Image",
    description: "$5/lb",
  },
  {
    name: "Medicine Waste",
    imageSrc: "/Types/medicine.jpg",
    altText: "Medicine Waste Image",
    description: "$1/lb",
  },
];
